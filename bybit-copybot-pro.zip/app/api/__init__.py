"""API module for health endpoints and monitoring."""

