"""App package initialization for bybit-copybot-pro.

This package will contain the application code in subsequent steps.
"""

